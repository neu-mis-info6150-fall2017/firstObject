/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author Kaiyuan
 */
public class FinancialAccount {
   String checkaccount;
   String saveaccount;
   String checkcreate;
   String savecreate;
   String checkstatus;
   String savestatus;
   String checkdc;
   String savedc;

    public String getCheckaccount() {
        return checkaccount;
    }

    public String getSaveaccount() {
        return saveaccount;
    }

    public String getCheckcreate() {
        return checkcreate;
    }

    public String getSavecreate() {
        return savecreate;
    }

    public String getCheckstatus() {
        return checkstatus;
    }

    public String getSavestatus() {
        return savestatus;
    }

    public String getCheckdc() {
        return checkdc;
    }

    public String getSavedc() {
        return savedc;
    }

    public void setCheckaccount(String checkaccount) {
        this.checkaccount = checkaccount;
    }

    public void setSaveaccount(String saveaccount) {
        this.saveaccount = saveaccount;
    }

    public void setCheckcreate(String checkcreate) {
        this.checkcreate = checkcreate;
    }

    public void setSavecreate(String savecreate) {
        this.savecreate = savecreate;
    }

    public void setCheckstatus(String checkstatus) {
        this.checkstatus = checkstatus;
    }

    public void setSavestatus(String savestatus) {
        this.savestatus = savestatus;
    }

    public void setCheckdc(String checkdc) {
        this.checkdc = checkdc;
    }

    public void setSavedc(String savedc) {
        this.savedc = savedc;
    }
}
